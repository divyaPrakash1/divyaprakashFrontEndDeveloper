import { Component } from '@angular/core';
import { ToDoService } from './todo.service';

@Component({
  selector: 'todolist-component',
  template: `
    <h3>ToDo List</h3>
	<table>
		<tr>
			<th>Mark done</th>
			<th>Name</th>
			<th>Description</th>
			<th>Repeat</th>
		</tr>
		<tr *ngFor="let item of todoList" [hidden]="item.done">
			<td><input type="checkbox" id="done" name="done" [(ngModel)]="item.done" value="true"></td>
			<td>{{item.taskName}}</td>
			<td>{{item.description}}</td>
			<td>{{item.isRepeat}}</td>
		</tr>
	</table>
  `
})
export class ToDoListComponent {
	todoList: any = "";
	
	constructor(private _toDoService: ToDoService){
		
	}
	
	ngOnInit(){
		this.todoList = this._toDoService.todoArray;
	}
}
import { Component } from '@angular/core';
import { ToDoService } from './todo.service';

@Component({
  selector: 'createtodo-component',
  template: `
    <label>Task Name</label>
	<input type="text" [(ngModel)]="taskName" (blur)="autoSubmit()">
	<label>Task Description</label>
	<textarea [(ngModel)]="description" (blur)="autoSubmit()"></textarea>
	<label>Repeating Task</label>
	<select [(ngModel)]="isRepeatingTask" (change)="autoSubmit()">
	  <option value="yes">Yes</option>
	  <option value="no">No</option>
	</select>
	<todolist-component></todolist-component>
	<donelist-component></donelist-component>
  `
})
export class CreateToDoComponent {
	taskName: string = "";
	description: string = "";
	isRepeatingTask: string = "";
	
	constructor(private _toDoService: ToDoService){
		
	}
	
	autoSubmit(){
		if(this.taskName == "" || this.description == "" || this.isRepeatingTask == ""){
			return;
		} else {
			let obj = {taskName: this.taskName, description: this.description, isRepeat: this.isRepeatingTask, done: false};
			this._toDoService.saveDetails(obj);
			this.taskName = "";
			this.description = "";
			this.isRepeatingTask = "";
		}
	}

}
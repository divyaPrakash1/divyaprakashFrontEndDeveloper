import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ToDoService {

  constructor() { }
  todoArray: any = [];
  
  saveDetails(obj){
	  this.todoArray.push(obj);
  }

}
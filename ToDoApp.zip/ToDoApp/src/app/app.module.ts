import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { CreateToDoComponent } from './createtodo.component';
import { ToDoListComponent } from './todolist.component';
import { DoneListComponent } from './donelist.component';

@NgModule({
  declarations: [
    CreateToDoComponent,ToDoListComponent,DoneListComponent
  ],
  imports: [
    BrowserModule,
	FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [CreateToDoComponent]
})
export class AppModule { }
